function figH=getfigH(fignumber)

figure(fignumber)
clf
figH=gca;
set(gcf,'WindowStyle','docked');
end